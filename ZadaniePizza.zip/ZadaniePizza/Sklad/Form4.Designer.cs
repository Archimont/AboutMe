﻿namespace Sklad
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Stol1 = new System.Windows.Forms.Button();
            this.Stol2 = new System.Windows.Forms.Button();
            this.Stol3 = new System.Windows.Forms.Button();
            this.Stol4 = new System.Windows.Forms.Button();
            this.Stol5 = new System.Windows.Forms.Button();
            this.dataObjednavka = new System.Windows.Forms.DataGridView();
            this.buttonOrder = new System.Windows.Forms.Button();
            this.buttonPay = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataObjednavka)).BeginInit();
            this.SuspendLayout();
            // 
            // Stol1
            // 
            this.Stol1.Location = new System.Drawing.Point(27, 26);
            this.Stol1.Name = "Stol1";
            this.Stol1.Size = new System.Drawing.Size(376, 70);
            this.Stol1.TabIndex = 0;
            this.Stol1.Text = "Stol1";
            this.Stol1.UseVisualStyleBackColor = true;
            this.Stol1.Click += new System.EventHandler(this.buttonStol1_Click);
            // 
            // Stol2
            // 
            this.Stol2.Location = new System.Drawing.Point(27, 102);
            this.Stol2.Name = "Stol2";
            this.Stol2.Size = new System.Drawing.Size(376, 70);
            this.Stol2.TabIndex = 1;
            this.Stol2.Text = "Stol2";
            this.Stol2.UseVisualStyleBackColor = true;
            this.Stol2.Click += new System.EventHandler(this.buttonStol2_Click);
            // 
            // Stol3
            // 
            this.Stol3.Location = new System.Drawing.Point(27, 178);
            this.Stol3.Name = "Stol3";
            this.Stol3.Size = new System.Drawing.Size(376, 70);
            this.Stol3.TabIndex = 2;
            this.Stol3.Text = "Stol3";
            this.Stol3.UseVisualStyleBackColor = true;
            this.Stol3.Click += new System.EventHandler(this.buttonStol3_Click);
            // 
            // Stol4
            // 
            this.Stol4.Location = new System.Drawing.Point(27, 254);
            this.Stol4.Name = "Stol4";
            this.Stol4.Size = new System.Drawing.Size(376, 70);
            this.Stol4.TabIndex = 3;
            this.Stol4.Text = "Terasa1";
            this.Stol4.UseVisualStyleBackColor = true;
            this.Stol4.Click += new System.EventHandler(this.buttonStol4_Click);
            // 
            // Stol5
            // 
            this.Stol5.Location = new System.Drawing.Point(27, 330);
            this.Stol5.Name = "Stol5";
            this.Stol5.Size = new System.Drawing.Size(376, 70);
            this.Stol5.TabIndex = 4;
            this.Stol5.Text = "Terasa2";
            this.Stol5.UseVisualStyleBackColor = true;
            this.Stol5.Click += new System.EventHandler(this.buttonStol5_Click);
            // 
            // dataObjednavka
            // 
            this.dataObjednavka.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataObjednavka.Location = new System.Drawing.Point(580, 26);
            this.dataObjednavka.Name = "dataObjednavka";
            this.dataObjednavka.RowHeadersWidth = 51;
            this.dataObjednavka.RowTemplate.Height = 24;
            this.dataObjednavka.Size = new System.Drawing.Size(679, 374);
            this.dataObjednavka.TabIndex = 5;
            // 
            // buttonOrder
            // 
            this.buttonOrder.Location = new System.Drawing.Point(409, 26);
            this.buttonOrder.Name = "buttonOrder";
            this.buttonOrder.Size = new System.Drawing.Size(165, 146);
            this.buttonOrder.TabIndex = 6;
            this.buttonOrder.Text = "Objednaj";
            this.buttonOrder.UseVisualStyleBackColor = true;
            this.buttonOrder.Click += new System.EventHandler(this.buttonOrder_Click_1);
            // 
            // buttonPay
            // 
            this.buttonPay.Location = new System.Drawing.Point(409, 254);
            this.buttonPay.Name = "buttonPay";
            this.buttonPay.Size = new System.Drawing.Size(165, 146);
            this.buttonPay.TabIndex = 7;
            this.buttonPay.Text = "Zaplat";
            this.buttonPay.UseVisualStyleBackColor = true;
            this.buttonPay.Click += new System.EventHandler(this.buttonPay_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(409, 178);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 17);
            this.label1.TabIndex = 8;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1326, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonPay);
            this.Controls.Add(this.buttonOrder);
            this.Controls.Add(this.dataObjednavka);
            this.Controls.Add(this.Stol5);
            this.Controls.Add(this.Stol4);
            this.Controls.Add(this.Stol3);
            this.Controls.Add(this.Stol2);
            this.Controls.Add(this.Stol1);
            this.Name = "Form4";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataObjednavka)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Stol1;
        private System.Windows.Forms.Button Stol2;
        private System.Windows.Forms.Button Stol3;
        private System.Windows.Forms.Button Stol4;
        private System.Windows.Forms.Button Stol5;
        private System.Windows.Forms.DataGridView dataObjednavka;
        private System.Windows.Forms.Button buttonOrder;
        private System.Windows.Forms.Button buttonPay;
        private System.Windows.Forms.Label label1;
    }
}