﻿namespace Sklad
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataPossibleMenu = new System.Windows.Forms.DataGridView();
            this.dataObjednavka = new System.Windows.Forms.DataGridView();
            this.buttonSubmit = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.textBoxRemove = new System.Windows.Forms.TextBox();
            this.textBoxAdd = new System.Windows.Forms.TextBox();
            this.buttonRemove = new System.Windows.Forms.Button();
            this.buttonAdd = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataPossibleMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataObjednavka)).BeginInit();
            this.SuspendLayout();
            // 
            // dataPossibleMenu
            // 
            this.dataPossibleMenu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataPossibleMenu.Location = new System.Drawing.Point(446, 12);
            this.dataPossibleMenu.Name = "dataPossibleMenu";
            this.dataPossibleMenu.RowHeadersWidth = 51;
            this.dataPossibleMenu.RowTemplate.Height = 24;
            this.dataPossibleMenu.Size = new System.Drawing.Size(301, 325);
            this.dataPossibleMenu.TabIndex = 0;
            this.dataPossibleMenu.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataMenu_CellContentClick);
            // 
            // dataObjednavka
            // 
            this.dataObjednavka.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataObjednavka.Location = new System.Drawing.Point(169, 12);
            this.dataObjednavka.Name = "dataObjednavka";
            this.dataObjednavka.RowHeadersWidth = 51;
            this.dataObjednavka.RowTemplate.Height = 24;
            this.dataObjednavka.Size = new System.Drawing.Size(256, 325);
            this.dataObjednavka.TabIndex = 1;
            this.dataObjednavka.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataObjednavka_CellContentClick);
            // 
            // buttonSubmit
            // 
            this.buttonSubmit.Location = new System.Drawing.Point(12, 126);
            this.buttonSubmit.Name = "buttonSubmit";
            this.buttonSubmit.Size = new System.Drawing.Size(112, 346);
            this.buttonSubmit.TabIndex = 2;
            this.buttonSubmit.Text = "Potvrdit";
            this.buttonSubmit.UseVisualStyleBackColor = true;
            this.buttonSubmit.Click += new System.EventHandler(this.buttonSubmit_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(12, 12);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(112, 87);
            this.buttonCancel.TabIndex = 3;
            this.buttonCancel.Text = "Zrusit";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // textBoxRemove
            // 
            this.textBoxRemove.Location = new System.Drawing.Point(169, 357);
            this.textBoxRemove.Name = "textBoxRemove";
            this.textBoxRemove.Size = new System.Drawing.Size(100, 22);
            this.textBoxRemove.TabIndex = 4;
            this.textBoxRemove.TextChanged += new System.EventHandler(this.textBoxRemove_TextChanged);
            // 
            // textBoxAdd
            // 
            this.textBoxAdd.Location = new System.Drawing.Point(446, 357);
            this.textBoxAdd.Name = "textBoxAdd";
            this.textBoxAdd.Size = new System.Drawing.Size(100, 22);
            this.textBoxAdd.TabIndex = 5;
            this.textBoxAdd.TextChanged += new System.EventHandler(this.textBoxAdd_TextChanged);
            // 
            // buttonRemove
            // 
            this.buttonRemove.Location = new System.Drawing.Point(169, 396);
            this.buttonRemove.Name = "buttonRemove";
            this.buttonRemove.Size = new System.Drawing.Size(100, 36);
            this.buttonRemove.TabIndex = 6;
            this.buttonRemove.Text = "vymaz";
            this.buttonRemove.UseVisualStyleBackColor = true;
            this.buttonRemove.Click += new System.EventHandler(this.buttonRemove_Click);
            // 
            // buttonAdd
            // 
            this.buttonAdd.Location = new System.Drawing.Point(446, 395);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(101, 37);
            this.buttonAdd.TabIndex = 7;
            this.buttonAdd.Text = "uloz";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(905, 501);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.buttonRemove);
            this.Controls.Add(this.textBoxAdd);
            this.Controls.Add(this.textBoxRemove);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonSubmit);
            this.Controls.Add(this.dataObjednavka);
            this.Controls.Add(this.dataPossibleMenu);
            this.Name = "Form5";
            this.Text = "Form5";
            this.Load += new System.EventHandler(this.Form5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataPossibleMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataObjednavka)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataPossibleMenu;
        private System.Windows.Forms.DataGridView dataObjednavka;
        private System.Windows.Forms.Button buttonSubmit;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.TextBox textBoxRemove;
        private System.Windows.Forms.TextBox textBoxAdd;
        private System.Windows.Forms.Button buttonRemove;
        private System.Windows.Forms.Button buttonAdd;
    }
}