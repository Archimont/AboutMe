﻿using PizzaLib.Classes;
using Sklad.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sklad
{
    /// <summary>
    /// trieda sluzi na pracu s aktualnou objednavkou
    /// </summary>
    public partial class Form5 : Form
    {
        private RestaurantMenu restaurantMenu;
        private Inventory inventory;
        private Order order;
        private BindingSource bindingSourceMain = new BindingSource();
        private BindingSource bindingSourceMenu = new BindingSource();
        private BindingSource bindingSourceOrder = new BindingSource();
        private List<ISellable> possibleMenu = new List<ISellable>();
        private List<ISellable> possibleOrder = new List<ISellable>();
        private List<ISellable> toAddtoPossibleOrder = new List<ISellable>();
        private List<ISellable> toRemovetoPossibleOrder = new List<ISellable>();

        public Form5()
        {
            InitializeComponent();
        }
        public Form5(RestaurantMenu menu, Inventory inventory, Order order) : this()
        {
            this.order = order;
            this.restaurantMenu = menu;
            this.inventory = inventory;
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            foreach (ISellable sellable in  restaurantMenu.GetSellables()) 
            {
                    sellable.SetInventory(inventory);
            }
            Func<ISellable, bool> predicate = polozka => polozka.IsPossielbeToOrder();
            possibleMenu = restaurantMenu.GetSellables().Where(predicate).ToList();
            bindingSourceMenu.DataSource = possibleMenu;
            dataPossibleMenu.DataSource = bindingSourceMenu;
            bindingSourceMenu.ResetBindings(false);

            toAddtoPossibleOrder.Add(possibleMenu.First());
           
        }
        /// <summary>
        /// zavrie form bez zmeny
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        /// <summary>
        /// ulozi zmeny aktualizuje objednavku a zavrie form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            order.UpdateOrder(possibleOrder);
            this.Close();
        }

        private void dataMenu_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataObjednavka_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        /// <summary>
        /// vyhladava v aktualnej objednavke polozku ktoru chceme stornovat
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBoxRemove_TextChanged(object sender, EventArgs e)
        {
            Func<ISellable, bool> predicate = polozka => polozka.Name.Contains(textBoxRemove.Text);
            toRemovetoPossibleOrder = possibleOrder.Where(predicate).ToList();
            bindingSourceOrder.DataSource = toRemovetoPossibleOrder;
            dataObjednavka.DataSource = bindingSourceOrder;
            bindingSourceOrder.ResetBindings(false);
        }
        /// <summary>
        /// stornuje polozku z objednavky
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonRemove_Click(object sender, EventArgs e)
        {
            try
            {
                possibleOrder.Remove(toRemovetoPossibleOrder.First());
            }
            catch { }
            bindingSourceOrder.DataSource = possibleOrder;
            dataObjednavka.DataSource = bindingSourceOrder;
            bindingSourceOrder.ResetBindings(false);
        }
        /// <summary>
        /// vyhladava polozku na pridanie do objednavky
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBoxAdd_TextChanged(object sender, EventArgs e)
        {
            Func<ISellable, bool> predicate = polozka => polozka.Name.Contains(textBoxAdd.Text);
            toAddtoPossibleOrder = possibleMenu.Where(predicate).ToList();
            bindingSourceMenu.DataSource = toAddtoPossibleOrder;
            dataPossibleMenu.DataSource = bindingSourceMenu;
            bindingSourceOrder.ResetBindings(false);
        }
        /// <summary>
        /// pridava polozku do objednavky
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonAdd_Click(object sender, EventArgs e)
        {
            possibleOrder.Add(toAddtoPossibleOrder.First());
            bindingSourceOrder.DataSource = possibleOrder;
            dataObjednavka.DataSource = bindingSourceOrder;
            bindingSourceOrder.ResetBindings(false);
        }
        /// <summary>
        /// vytvori novu polozku
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>


        private void dataMenu_CellContentClick_1(object sender, DataGridViewCellEventArgs e) { }

    }
}
