﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PizzaLib;
using PizzaLib.Classes;

namespace Sklad
{
    /// <summary>
    /// trieda sluzi na priame pridavanie poloziek do skladu
    /// </summary>
    public partial class Form3 : Form
    {
        Inventory inventory;
        public Form3()
        {
            InitializeComponent();
        }
        public Form3(Inventory inventory) : this()
        {
            this.inventory = inventory;
            
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// zavrie form bez zmeny
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }
        /// <summary>
        /// prida novu polozku do skladu typu Ingredient s nastavenymi parametrami
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonSave_Click(object sender, EventArgs e)
        {
            try
            {
                Ingredient newItem = new Ingredient(textName.Text, Convert.ToDouble(textAmount.Text, CultureInfo.InvariantCulture), Convert.ToDouble(textWarningTreshold.Text, CultureInfo.InvariantCulture));
                inventory.AddItem(newItem);
            }
            catch { };
            DialogResult = DialogResult.Cancel;
            this.Close();
        }
        /// <summary>
        /// prida novu polozku do skladu typu MiscellaneousItem s nastavenymi parametrami
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void buttonMlska_Click(object sender, EventArgs e)
        {
            try
            {
                MiscellaneousItem newItem = new MiscellaneousItem(textName.Text, Convert.ToDouble(textAmount.Text, CultureInfo.InvariantCulture), Convert.ToDouble(textWarningTreshold.Text, CultureInfo.InvariantCulture), Convert.ToDouble(textPrice.Text, CultureInfo.InvariantCulture));
                inventory.AddItem(newItem);
            }
            catch { };
            DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
