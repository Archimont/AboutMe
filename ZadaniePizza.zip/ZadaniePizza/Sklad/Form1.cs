﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PizzaLib;
using PizzaLib.Classes;

namespace Sklad
{
    /// <summary>
    /// vizualizacia skladu trieda urcena na pracu s polozkami v inventory
    /// </summary>
    public partial class Form1 : Form
    {
        private BindingSource bindingSource = new BindingSource();
        private BindingSource bindingSourceMain = new BindingSource();
        private Inventory inventory;
        RestaurantMenu restaurantMenu;
        public Form1()
        {
            InitializeComponent();
        }
        public Form1(Inventory inventory,RestaurantMenu restaurantMenu) : this()
        {
            this.inventory = inventory;
            this.restaurantMenu = restaurantMenu;
        }
        /// <summary>
        /// nacita aktualne polozky v inventory
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            bindingSource.DataSource = inventory.GetItems();          
            dataSklad.DataSource = bindingSource;
            bindingSource.ResetBindings(false);
            bindingSourceMain.DataSource = restaurantMenu.GetPizzas();
            dataMenu.DataSource = bindingSourceMain;
            dataMenu.AutoResizeColumns();
            bindingSourceMain.ResetBindings(false);
        }
        /// <summary>
        /// vyhladava polozky podla nazvu polozky 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
          //  bool predicate(AbstractItem polozka)  => polozka.Name == textBox1.Text;
            Func<AbstractItem, bool> predicate = item => item.Name.Contains(textBox1.Text);

            bindingSource.DataSource = inventory.GetItemsByPredicate(predicate);
            bindingSource.ResetBindings(false);
        }
        /// <summary>
        /// nastavuje parametre polozky
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataSklad_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            AbstractItem item = (AbstractItem)dataSklad.CurrentRow.DataBoundItem;
            using (Form2 form = new Form2(item))
            {
                form.ShowDialog();
                if (form.DialogResult == DialogResult.OK)
                {
                    bindingSource.DataSource = inventory.GetItems();
                    bindingSource.ResetBindings(false);
                }
            }
        }
        /// <summary>
        /// prida polozku do skladu
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonNew_Click(object sender, EventArgs e)
        {
            using (Form3 form = new Form3(this.inventory))
            {
                form.ShowDialog();
            }
            bindingSource.DataSource = inventory.GetItems();
            bindingSource.ResetBindings(false);
        }

        private void buttonAddMlska_Click(object sender, EventArgs e)
        {
            using (Form6 form = new Form6(restaurantMenu))
            {
                form.ShowDialog();
            }
            foreach (ISellable sellable in restaurantMenu.GetSellables())
            {
                sellable.SetInventory(inventory);
            }
            bindingSourceMain.DataSource = restaurantMenu.GetPizzas();
            dataMenu.DataSource = bindingSourceMain;
            bindingSourceMain.ResetBindings(false);
        }
    }
}
