﻿namespace Sklad
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataSklad = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.buttonNew = new System.Windows.Forms.Button();
            this.dataMenu = new System.Windows.Forms.DataGridView();
            this.buttonAddMlska = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataSklad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataMenu)).BeginInit();
            this.SuspendLayout();
            // 
            // dataSklad
            // 
            this.dataSklad.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataSklad.Location = new System.Drawing.Point(38, 16);
            this.dataSklad.Name = "dataSklad";
            this.dataSklad.RowHeadersWidth = 51;
            this.dataSklad.RowTemplate.Height = 24;
            this.dataSklad.Size = new System.Drawing.Size(450, 328);
            this.dataSklad.TabIndex = 0;
            this.dataSklad.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataSklad_CellContentClick);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(38, 350);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(179, 22);
            this.textBox1.TabIndex = 1;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // buttonNew
            // 
            this.buttonNew.Location = new System.Drawing.Point(38, 390);
            this.buttonNew.Name = "buttonNew";
            this.buttonNew.Size = new System.Drawing.Size(179, 38);
            this.buttonNew.TabIndex = 2;
            this.buttonNew.Text = "Pridat Polozku";
            this.buttonNew.UseVisualStyleBackColor = true;
            this.buttonNew.Click += new System.EventHandler(this.buttonNew_Click);
            // 
            // dataMenu
            // 
            this.dataMenu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataMenu.Location = new System.Drawing.Point(502, 16);
            this.dataMenu.Name = "dataMenu";
            this.dataMenu.RowHeadersWidth = 51;
            this.dataMenu.RowTemplate.Height = 24;
            this.dataMenu.Size = new System.Drawing.Size(844, 328);
            this.dataMenu.TabIndex = 3;
            // 
            // buttonAddMlska
            // 
            this.buttonAddMlska.Location = new System.Drawing.Point(502, 390);
            this.buttonAddMlska.Name = "buttonAddMlska";
            this.buttonAddMlska.Size = new System.Drawing.Size(162, 38);
            this.buttonAddMlska.TabIndex = 4;
            this.buttonAddMlska.Text = "pridaj Pizzu";
            this.buttonAddMlska.UseVisualStyleBackColor = true;
            this.buttonAddMlska.Click += new System.EventHandler(this.buttonAddMlska_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1385, 450);
            this.Controls.Add(this.buttonAddMlska);
            this.Controls.Add(this.dataMenu);
            this.Controls.Add(this.buttonNew);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dataSklad);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataSklad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataMenu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataSklad;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button buttonNew;
        private System.Windows.Forms.DataGridView dataMenu;
        private System.Windows.Forms.Button buttonAddMlska;
    }
}

