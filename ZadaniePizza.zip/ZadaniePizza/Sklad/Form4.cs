﻿using PizzaLib.Classes;
using Sklad.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sklad
{
    /// <summary>
    /// trieda sluzi na vizualizaciu stolov a objednavok
    /// </summary>
    public partial class Form4 : Form
    {
        private Order actualOrder;
        private Button actualButton;
        private RestaurantMenu restaurantMenu;
        private Inventory inventory;
        private BindingSource bindingSource = new BindingSource();
        private Dictionary<Button, Order> orders = new Dictionary<Button, Order>();
        public Form4()
        {
            InitializeComponent();
        }
        public Form4(RestaurantMenu menu , Inventory inventory) :this()
        {
            this.restaurantMenu = menu;
            this.inventory = inventory;
        }
        /// <summary>
        /// vykona platbu aktualnej objednavky
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonPay_Click(object sender, EventArgs e)
        {
            Blocek blocek = Blocek.GetInstance();
            blocek.SetBlocek(actualOrder);
            actualOrder.payed();
            bindingSource.DataSource = actualOrder.GetOrder();
            dataObjednavka.DataSource = bindingSource;
            bindingSource.ResetBindings(false);
            label1.Text = string.Format(" {0} vyplatil {1} ", actualButton.Text, blocek.GetPay());
        }

        private void buttonStol1_Click(object sender, EventArgs e)
        {
            Clicked((Button)Stol1);
        }

        private bool OrderExist(Button buttonStol) 
        {
            return orders.Any(stol => stol.Key == buttonStol);
        }
        /// <summary>
        /// prejde na aktualnu objednavku stola ak objednavka pre stol este neexistuje vytvori novu 
        /// nasledne vizualizuje danu objednavku a nastavi stol aj objednavku na aktualnu
        /// </summary>
        /// <param name="sender"></param>
        private void Clicked(Button sender) 
        {
            if (!OrderExist(sender))
            {
                orders.Add(sender, new Order(new List<ISellable>()));
            }
            KeyValuePair<Button, Order> table = orders.First(objednavka => objednavka.Key == sender);
            actualOrder = table.Value;
            actualButton = table.Key;
            bindingSource.DataSource = actualOrder.GetOrder();
            dataObjednavka.DataSource = bindingSource;
            bindingSource.ResetBindings(false);
        }

        private void buttonStol2_Click(object sender, EventArgs e)
        {
            Clicked((Button)Stol2);
        }

        private void buttonStol3_Click(object sender, EventArgs e)
        {
            Clicked((Button)Stol3);
        }

        private void buttonStol4_Click(object sender, EventArgs e)
        {
            Clicked((Button)Stol4);
        }

        private void buttonStol5_Click(object sender, EventArgs e)
        {
            Clicked((Button)Stol5);
        }
        /// <summary>
        /// aktualizuje aktualnu objednavku
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonOrder_Click_1(object sender, EventArgs e)
        {
            if (actualOrder == null) { return; }
            using (Form5 tables = new Form5(restaurantMenu, inventory,actualOrder))
            {
                tables.ShowDialog();
            }
            bindingSource.DataSource = actualOrder.GetOrder();
            dataObjednavka.DataSource = bindingSource;
            bindingSource.ResetBindings(false);
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
    }
}
