﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PizzaLib;
using PizzaLib.Classes;

namespace Sklad.Classes
{
    public class Tables
    {
        /// <summary>
        /// neviem na co som mal vyuzit toto 
        /// </summary>
        Dictionary<Button, Order> stoly = new Dictionary<Button, Order>();
        public Tables() 
        {
        
        }
    }
}
