﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PizzaLib;
using PizzaLib.Classes;

namespace Sklad.Classes
{
    /// <summary>
    /// trieda urcena na pracu s objednavkou pri stole
    /// </summary>
    public class Order
    {
        private List<ISellable> sellables;
        public Order(List<ISellable> sellables) 
        {
            this.sellables = sellables ;
        }

        /// <summary>
        /// pri plateni sa objednavka vyprazdni ale dvojica stol objednavka ostava
        /// </summary>
        public void payed() 
        {
            sellables.Clear();
        }
        /// <summary>
        /// vrati zoznam objednanych poloziek
        /// </summary>
        /// <returns></returns>
        public List<ISellable> GetOrder() 
        {
            return this.sellables;
        }
        /// <summary>
        /// pri objednani dalsej polozky sa objednavka aktualizuje
        /// </summary>
        /// <param name="orders"></param>
        public void UpdateOrder(List<ISellable> orders) 
        {         
            foreach (ISellable order in orders) 
            {
                try
                {
                    order.Order();
                    sellables.Add(order);
                }
                catch { }
            }
        } 
    }
}
