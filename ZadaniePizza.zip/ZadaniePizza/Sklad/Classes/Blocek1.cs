﻿using PizzaLib.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sklad.Classes
{
    /// <summary>
    /// trieda urcena na tlacenie blocku a platenie objednavky
    /// </summary>
    public class Blocek
    {
        private static Blocek blocek;
        List<ISellable> platba = new List<ISellable>();
        private double vyslednaSuma = 0;
        private Blocek() { }
        /// <summary>
        /// vracia jedinecny blocek
        /// </summary>
        /// <returns></returns>
        public static Blocek GetInstance()
        {
            if (blocek == null)
            {
                blocek = new Blocek();
            }
            return blocek;
        }
        /// <summary>
        /// nastavuje blocek na novy
        /// </summary>
        /// <param name="order"></param>
        public void SetBlocek(Order order) 
        {
            vyslednaSuma = 0;
            platba = order.GetOrder();
            platba.ForEach(x => vyslednaSuma += x.Price);
        }
        /// <summary>
        /// vracia celkovu hodnotu objednavky
        /// </summary>
        /// <returns></returns>
        public double GetPay() 
        {
            return this.vyslednaSuma;
        }
    }
}
