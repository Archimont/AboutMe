﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PizzaLib;
using PizzaLib.Classes;

namespace Sklad
{
    /// <summary>
    /// trieda sluzi na upravovanie polozky v sklade
    /// </summary>
    public partial class Form2 : Form
    {
        AbstractItem actualitem;
        public Form2()
        {
            InitializeComponent();
        }
        /// <summary>
        /// predavanie referencie polozky ktoru chceme upravit
        /// </summary>
        /// <param name="polozka"></param>
        public Form2(AbstractItem polozka) : this()
        {
            this.actualitem = polozka;
            textName.Text = actualitem.Name;
            textAmount.Text = Convert.ToString(actualitem.Amount);
            textWarwingTreshold.Text = Convert.ToString(actualitem.WarningTreshold);
        }
        /// <summary>
        /// ulozi aktualne parametre polozky 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ButtonSave_Click(object sender, EventArgs e)
        {
            try
            {
                actualitem.SetName(textName.Text);
                actualitem.SetAmount(Convert.ToDouble(textAmount.Text, CultureInfo.InvariantCulture));
                actualitem.SetWarningTreshold(Convert.ToDouble(textWarwingTreshold.Text, CultureInfo.InvariantCulture));
            }
            catch { }
            DialogResult = DialogResult.OK;
            this.Close();

        }
        /// <summary>
        /// zavrie form 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void textAmount_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
