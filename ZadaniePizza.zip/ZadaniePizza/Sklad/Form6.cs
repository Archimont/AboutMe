﻿using System;
using PizzaLib.Classes;
using Sklad.Classes;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace Sklad
{
    /// <summary>
    /// trieda sluzi na vytvaranie novej pizze do menu
    /// </summary>
    public partial class Form6 : Form
    {
        RestaurantMenu restaurantMenu;
        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }
        public Form6(RestaurantMenu menu) : this()
        {
            this.restaurantMenu = menu;
        }
        /// <summary>
        /// ulozi novu pizzu ak su spravne zadane parametre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonSave_Click(object sender, EventArgs e)
        {
            try
            {
                string[] data = textBoxIngredients.Text.Split(',');
                Dictionary<string, double> dict = new Dictionary<string, double>();
                for (int i = 0; i < data.Length; i += 2)
                {
                    dict.Add(data[i], Convert.ToDouble(data[i + 1], CultureInfo.InvariantCulture));
                }

                restaurantMenu.AddSellabe(new Pizza(textBoxNazov.Text, Convert.ToDouble(textBoxCena.Text, CultureInfo.InvariantCulture), dict));
                this.Close();
            }
            catch {}
            this.Close();
        }
        /// <summary>
        /// zatvori form bez zmeny
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonStorno_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
