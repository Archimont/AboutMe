﻿namespace Sklad
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textName = new System.Windows.Forms.TextBox();
            this.textWarwingTreshold = new System.Windows.Forms.TextBox();
            this.textPrice = new System.Windows.Forms.TextBox();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.ButtonSave = new System.Windows.Forms.Button();
            this.textAmount = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textName
            // 
            this.textName.Location = new System.Drawing.Point(28, 35);
            this.textName.Name = "textName";
            this.textName.Size = new System.Drawing.Size(185, 22);
            this.textName.TabIndex = 0;
            // 
            // textWarwingTreshold
            // 
            this.textWarwingTreshold.Location = new System.Drawing.Point(28, 116);
            this.textWarwingTreshold.Name = "textWarwingTreshold";
            this.textWarwingTreshold.Size = new System.Drawing.Size(185, 22);
            this.textWarwingTreshold.TabIndex = 2;
            // 
            // textPrice
            // 
            this.textPrice.Location = new System.Drawing.Point(28, 158);
            this.textPrice.Name = "textPrice";
            this.textPrice.Size = new System.Drawing.Size(185, 22);
            this.textPrice.TabIndex = 3;
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(364, 291);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(217, 49);
            this.buttonCancel.TabIndex = 4;
            this.buttonCancel.Text = "Zrusit";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // ButtonSave
            // 
            this.ButtonSave.Location = new System.Drawing.Point(28, 291);
            this.ButtonSave.Name = "ButtonSave";
            this.ButtonSave.Size = new System.Drawing.Size(217, 49);
            this.ButtonSave.TabIndex = 5;
            this.ButtonSave.Text = "Ulozit";
            this.ButtonSave.UseVisualStyleBackColor = true;
            this.ButtonSave.Click += new System.EventHandler(this.ButtonSave_Click);
            // 
            // textAmount
            // 
            this.textAmount.Location = new System.Drawing.Point(28, 77);
            this.textAmount.Name = "textAmount";
            this.textAmount.Size = new System.Drawing.Size(185, 22);
            this.textAmount.TabIndex = 7;
            this.textAmount.TextChanged += new System.EventHandler(this.textAmount_TextChanged);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textAmount);
            this.Controls.Add(this.ButtonSave);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.textPrice);
            this.Controls.Add(this.textWarwingTreshold);
            this.Controls.Add(this.textName);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textName;
        private System.Windows.Forms.TextBox textWarwingTreshold;
        private System.Windows.Forms.TextBox textPrice;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Button ButtonSave;
        private System.Windows.Forms.TextBox textAmount;
    }
}