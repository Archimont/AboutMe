﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaLib.Classes
{
    /// <summary>
    /// interface na pracu s polozkami
    /// </summary>
    interface IItem
    {
        /// <summary>
        /// vracia aktualne mnozstvo polozky
        /// </summary>
        /// <returns></returns>
        double GetAmount();
        /// <summary>
        /// zistuje ci mnozstvo polozky neprekrocilo kriticku hodnotu
        /// </summary>
        /// <returns></returns>
        bool IsLow();
        /// <summary>
        /// sluzi na "dodavanie" mnozstva polozky
        /// </summary>
        /// <param name="amount"></param>
        void Add(double amount);
        /// <summary>
        /// sluzi na "odoberanie" mnozstva polozky
        /// </summary>
        /// <param name="amount"></param>
        void Remove(double amount);

    }
}
