﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaLib.Classes
{
    //TH - december 2019
    /*Poznamky:
     * Surovina nie na pripravu pizze ale na predaj napr: chrumky, cola...
     * Uklada sa do Csv suboru pre sklad;
     */
    /// <summary>
    /// Surovina nie na pripravu pizze ale na predaj
    /// </summary>
    public class MiscellaneousItem : AbstractItem , ISellable
    {
        public MiscellaneousItem(string name, double initialAmount, double warningTreshold, double price) : base(name, initialAmount, warningTreshold)
        {
            this.price = price;
        }

        private double price;
        public double Price
        {
            get { return price; }
        }


        public double GetPrice(double cena)
        {
            return this.price;
        }

        public void Order()
        {
            Remove(1);
        }

        override public string ToCsvLine()
        {
            return string.Format("{0},{1},{2},{3},{4}","MiscellaneousItem" , GetName(), Convert.ToString(GetAmount(), CultureInfo.InvariantCulture), Convert.ToString(GetWarningTreshold(), CultureInfo.InvariantCulture) , Convert.ToString(price, CultureInfo.InvariantCulture));
        }

        public bool IsPossielbeToOrder()
        {
            return Amount > 1; 
        }

        public void SetInventory(IInventory inventory) { }

    }
}
