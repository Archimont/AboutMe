﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaLib.Classes
{
    /// <summary>
    /// Trieda sluzi na pracu s menu v restauracii
    /// obsahuje polozky ktore je mozno predat
    /// </summary>
    public class RestaurantMenu 
    {
        List<ISellable> sellables;
        List<ICsvSerializable> CSVprvkyy;
        List<Pizza> pizzas = new List<Pizza>();
        public RestaurantMenu(List<ISellable> sellables, List<ICsvSerializable> CSVprvky)
        {
            this.CSVprvkyy = CSVprvky;
            this.sellables = sellables;
            foreach (ISellable sellable in sellables) 
            {
                if (sellable is Pizza) { pizzas.Add((Pizza)sellable); }
            }
        }
        /// <summary>
        /// vracia zoznam poloziek ktore obsahuje menu v restauracii
        /// </summary>
        /// <returns></returns>
        public List<ISellable> GetSellables()
        {
            return sellables;
        }
        /// <summary>
        /// pridava novu predajnu polozku do menu restauracie
        /// </summary>
        /// <param name="sellable"></param>
        public void AddSellabe(ISellable sellable)
        {
            if (!ItemExists(sellable)) 
            {
                sellables.Add(sellable);
                CSVprvkyy.Add((ICsvSerializable)sellable);
                if (sellable is Pizza) { pizzas.Add((Pizza)sellable); }
            }
            else
                throw new ArgumentException($"Polozka {nameof(sellable)} v restaurantmenu uz existuje");
        }
        /// <summary>
        /// zistuje ci sa polozka nachadza v restauracnom menu
        /// </summary>
        /// <param name="polozka"></param>
        /// <returns></returns>
        bool ItemExists(ISellable polozka)
        {
            bool result = sellables.Any(p => p.Name == polozka.Name);
            return result;
        }
        /// <summary>
        /// vracia zoznam poloziek v restauracnom menu ktory splna nejaku podmienku 
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        public List<ISellable> GetSellablesByPredicate(Func<ISellable, bool> predicate)
        {
            return sellables.Where(predicate).ToList(); 
        }

        public List<Pizza> GetPizzas() 
        {
            return this.pizzas;
        }

    }
}
