﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaLib.Classes
{
    // TH - december 2019
    /*Poznamky:
     * Pizza je zlozena z ingrediencii 
     * Pizza ktora bola vyrobena sa uklada do suboru vyrobenePizze.csv
     * Ingrediencie potrebne na vyrobu pizze su ulozene v subore recepty.json
     */
     /// <summary>
     /// 
     /// </summary>
    public class Pizza : ISellable, ICsvSerializable
    {
        public Pizza(string name, double price, Dictionary<string , double> rawMaterials)
        {
            this.name = name;
            this.price = price;
            this.rawMaterials = rawMaterials;
            string nameofingredients = ""; 
            foreach (KeyValuePair<string,double> ingredient in rawMaterials) 
            {
                nameofingredients += ingredient.Key + " " + Convert.ToString(ingredient.Value, CultureInfo.InvariantCulture) +", ";
            }
            this.ingredients = nameofingredients;
        }

        private IInventory inventory;

        /// <summary>
        /// sluzi na zistenie z ktoreho inventaru ma pizza pri vyrobe odoberat suroviny
        /// </summary>
        /// <param name="inventory"></param>
        public void SetInventory(IInventory inventory)
        {
            this.inventory = inventory;
        }


        #region == PROPERTIES/FIELDS ==

        Dictionary<string, double> rawMaterials;//double je mnozstvo itemu napr. 0.5 kg muky 

        double price;
        public double Price => price;

        private string name;
        public string Name => name;

        private string ingredients;
        public string Ingredients => ingredients;

        #endregion == PROPERTIES/FIELDS ==

        #region ===Funkcie===
        /// <summary>
        /// zistuje cenu pizze
        /// </summary>
        /// <param name="cena"></param>
        /// <returns></returns>
        public double GetPrice(double cena)
        {
            return this.price;
        }
        /// <summary>
        /// vykona objednavku pizze odoberie ingrediencie zo skladu
        /// </summary>
        public void Order()
        {
            Dictionary<Ingredient, double> dict = new Dictionary<Ingredient, double>();
            AbstractItem item;
            foreach (KeyValuePair<string, double> raw in rawMaterials)
            {
                bool IsSame(AbstractItem polozkaVsklade) => polozkaVsklade.Name == raw.Key;
                item = inventory.GetItem(IsSame);
                dict.Add((Ingredient)item,raw.Value);
                if (item.GetAmount() < raw.Value) 
                {
                    item.Remove(raw.Value);
                    return;
                }
            }
            foreach (KeyValuePair<Ingredient, double> material in dict)
            {
                material.Key.Remove(material.Value);
            }

        }

        /// <summary>
        /// pretypuje pizzu do string formatu aby bolo mozne zapisat ju do suboru
        /// </summary>
        /// <returns></returns>
        public string ToCsvLine()
        {
            string pizza =  string.Format("{0},{1},{2}","Pizza" ,Name, Convert.ToString(price, CultureInfo.InvariantCulture));
            foreach ( KeyValuePair<string, double> raw in rawMaterials)
            {
                pizza += string.Format(",{0},{1}", Convert.ToString(raw.Key, CultureInfo.InvariantCulture), Convert.ToString(raw.Value, CultureInfo.InvariantCulture));
            }
            return pizza;
        }
        /// <summary>
        /// zistuje ci je mozne objednat pizzu s aktualnym mnozstvom materialov v sklade
        /// </summary>
        /// <returns></returns>
        public bool IsPossielbeToOrder()
        {
            Dictionary<Ingredient, double> dict = new Dictionary<Ingredient, double>();
            AbstractItem item;
            foreach (KeyValuePair<string, double> raw in rawMaterials)
            {
                bool IsSame(AbstractItem polozkaVsklade) => polozkaVsklade.Name == raw.Key;
                item = inventory.GetItem(IsSame);
                dict.Add((Ingredient)item, raw.Value);
                if (item.GetAmount() < raw.Value)
                {
                    return false;
                }
            }
            return true;
        }

        #endregion ===Funkcie===
    }
}
