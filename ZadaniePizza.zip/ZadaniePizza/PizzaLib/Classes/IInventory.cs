﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaLib.Classes
{
    public interface IInventory
    {
        /// <summary>
        /// funkcia pre ziskanie vsetkych poloziek z inventara
        /// </summary>
        /// <returns>List poloziek </returns>
        List<AbstractItem > GetItems();
        /// <summary>
        /// funkcia pre ziskanie poloziek z inventara na zaklade podmienky
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns> list poloziek splnajucich podmienku</returns>
        AbstractItem  GetItem(Predicate<AbstractItem > predicate);
        /// <summary>
        /// funkcia pre pridavanie poloziek do inventara
        /// </summary>
        /// <param name="item"></param>
        void AddItem(AbstractItem  item);

    }
}
