﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaLib.Classes
{
    /// <summary>
    /// sluzi na zapis a citanie zo suboru 
    /// inicializujem novy inventory a restaurant menu v konstruktore
    /// </summary>
    public class Fasada
    {
        private Inventory inventory;
        private RestaurantMenu restaurantMenu;
        IEnumerable<ICsvSerializable> CSVFromFileLines;
        CsvFileHelper helper;
        List<ICsvSerializable> CSVtoFileLines = new List<ICsvSerializable>();
        
        /// <summary>
        /// pouzitim CsvFileHelper nacita data zo suboru 
        /// </summary>

        public Fasada()
        {
            List<AbstractItem> ToInvetory = new List<AbstractItem>();
            List<ISellable> ToRestaurantMenu = new List<ISellable>();
            helper = new CsvFileHelper(@"zoznamPoloziek.txt");
            CSVFromFileLines = helper.LoadFromFile();
            foreach (ICsvSerializable CSVpredmet in CSVFromFileLines)
            {
                if (CSVpredmet is AbstractItem)
                {
                    ToInvetory.Add((AbstractItem)CSVpredmet);
                }
                if (CSVpredmet is ISellable) 
                {
                    ToRestaurantMenu.Add((ISellable)CSVpredmet);
                }
                CSVtoFileLines.Add(CSVpredmet);
            }
            this.inventory = new Inventory(ToInvetory, CSVtoFileLines);
            this.restaurantMenu = new RestaurantMenu(ToRestaurantMenu, CSVtoFileLines);
        }

        /// <summary>
        /// ukoncenie a ulozenie vykonavania programu
        /// </summary>
        public void SaveActualPizzeria() 
        {
            helper.SaveToFile(CSVtoFileLines);
        }

        /// <summary>
        /// odovzda referenciu na inventory
        /// </summary>
        /// <returns></returns>

        public Inventory getInventory() 
        {
           return this.inventory; 
        }
        /// <summary>
        /// odovzda referenciu  na restaurantmenu
        /// </summary>
        /// <returns></returns>
        public RestaurantMenu GetRestaurantMenu() 
        {
            return this.restaurantMenu;
        }
    }
}
