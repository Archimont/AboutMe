﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaLib.Classes
{
    // TH - december 2019
    /// <summary>
    /// definuje veci, ktoré sa dajú predať
    /// </summary>
    public interface ISellable
    {
        /// <summary>
        /// nastavi z ktoreho inventara sa maju vyberat polozky
        /// </summary>
        /// <param name="inventory"></param>
        void SetInventory(IInventory inventory);
        /// <summary>
        /// zistuje ci je mozny vyber polozky z inventara
        /// </summary>
        /// <returns></returns>
        bool IsPossielbeToOrder();
        /// <summary>
        /// vracia meno polozky
        /// </summary>
        string Name { get; }
        /// <summary>
        /// vracia hodnotu polozky
        /// </summary>
        double Price { get; }
        /// <summary>
        /// vracia hodnotu polozky (nerozumiem preco getPrice obsahuje parameter cena ??? SetPrice ???)
        /// ahaa to som zle opisal zo zadania ale uz pristupujem cez getter ...
        /// </summary>
        /// <param name="cena"></param>
        /// <returns></returns>
        double GetPrice(double cena);
        /// <summary>
        /// vykona objednavku polozky odoberie suroviny zo skladu
        /// </summary>
        void Order();
    }
}
