﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaLib.Classes
{

    //th december 2019
    /// <summary>
    /// Funkcia pre zapis do csv suboru
    /// </summary>
    public interface ICsvSerializable
    {
        string ToCsvLine();
    }
}
