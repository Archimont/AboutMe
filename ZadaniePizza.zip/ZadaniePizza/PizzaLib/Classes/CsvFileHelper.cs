﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaLib.Classes
{
    //TH - december 2019
    // pozn : pri práci so súbormi používajte IDisposable pattern.
    /// <summary>
    /// trieda zodpovedná za čítanie a zápis CSV súborov
    /// </summary>
    public class CsvFileHelper
    {
        /* poznamky:
         * pri zapise do csv suboru sa zaznamy- riadky zo suboru nacitaju do List<string>  
         * urobi sa kontrola ci uz pre meno existuje zaznam 
         * ak zaznam existuje prepise sa na nove hodnoty a List<string> sa ulozi do Csv suboru
         * ak zaznam neexistuje , zaznam sa prida do List<string> a ulozi sa do Csv suboru
         * 
         */

         // uplna cesta k Csv suboru
         readonly string fileName;

        public CsvFileHelper(string path) 
        {
            this.fileName = path;
        }

        /// <summary>
        /// polozku prida alebo upravi zaznam v Csv subore
        /// </summary>
        /// <param name="polozka"></param>
        public  void SaveToFile(List<ICsvSerializable> items) 
        {
            using (StreamWriter streamWriter = new StreamWriter(fileName)) 
            {
                foreach (ICsvSerializable item in items)
                {
                    if (item is Ingredient) 
                        streamWriter.WriteLine(item.ToCsvLine());
                }
                foreach (ICsvSerializable item in items)
                {
                    if (item is MiscellaneousItem)
                        streamWriter.WriteLine(item.ToCsvLine());
                }
                foreach (ICsvSerializable item in items)
                {
                    if (item is Pizza)
                        streamWriter.WriteLine(item.ToCsvLine());
                }
            }
        }



        /// <summary>
        /// vrati vsetky zaznamy v Csv subore
        /// </summary>
        /// <returns></returns>
        public  IEnumerable<ICsvSerializable> LoadFromFile() 
        {
            List<ICsvSerializable> lines = new List<ICsvSerializable>();
            using (StreamReader sr = new StreamReader(fileName))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    lines.Add(Deserialize(line));
                }
            }

            return lines;
        }

        /// <summary>
        /// vrati Item vytvoreny zo zaznamu v Csv subore
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public  ICsvSerializable Deserialize(string line) 
        {
            /*Poznamky:
             * V subore najst zaznam pre zadanu polozkiu ;
             * zo zaznamu nacitat typ polozky a podla typu vytvorit novu instanciu 
             * ICsvSerializable novaPolozka = new Ingredient( name,initialAmount, warningTreshold);
             * ICsvSerializable novaPolozka = new MiscellaneousItem( name,initialAmount, warningTreshold,cena);
             * ICsvSerializable novaPolozka = new Pizza( name, price, dict);
             */
            string[] data = line.Split(',');
            if (data[0] == "Ingredient" ) 
            {
                return new Ingredient(data[1], Convert.ToDouble(data[2], CultureInfo.InvariantCulture), Convert.ToDouble(data[3], CultureInfo.InvariantCulture));
            }
            if (data[0] == "MiscellaneousItem" )
            {
                return new MiscellaneousItem(data[1], Convert.ToDouble(data[2], CultureInfo.InvariantCulture), Convert.ToDouble(data[3], CultureInfo.InvariantCulture), Convert.ToDouble(data[4], CultureInfo.InvariantCulture));
            }
            if (data[0] == "Pizza" )
            {
                Dictionary<string, double> dict = new Dictionary<string, double>();
                for (int i = 3 ; i < data.Length ; i += 2)
                {
                    dict.Add(data[i], Convert.ToDouble(data[i+1], CultureInfo.InvariantCulture) );
                }
                return new Pizza(data[1], Convert.ToDouble(data[2], CultureInfo.InvariantCulture), dict);
            }
            return null;
        }
    }
}
