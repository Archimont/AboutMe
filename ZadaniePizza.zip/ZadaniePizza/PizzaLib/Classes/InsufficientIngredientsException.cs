﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaLib.Classes
{
    //TH - december 2019
    /// <summary>
    /// vynimka odpalena pri poklese mnozstva pod kriticku hodnotu
    /// </summary>
    public class InsufficientIngredientsException : Exception
    {
        public InsufficientIngredientsException(string message) : base(message) 
        {

        }
    }
}
