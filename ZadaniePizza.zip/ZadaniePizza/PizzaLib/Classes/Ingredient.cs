﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaLib.Classes
{
    //TH - december 2019
    /*Poznamky:
     * Ingredient surovina na pripravu pizze uklada sa do Csv suboru pre sklad
     * 
     * 
     */
    /// <summary>
    /// 
    /// </summary>
    public class Ingredient :AbstractItem 
    {
        public Ingredient(string name, double initialAmount, double warningTreshold) : base(name, initialAmount, warningTreshold)
        {


        }
    }
}
