﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaLib.Classes
{
    //TH - december 2019
    /// <summary>
    /// popisuje polozku v sklade
    /// definuje všeobecné správanie artiklov v sklade, musí obsahovať aspoň meno a hmotnosť / objem materiálu
    /// </summary>
    public class AbstractItem  : IItem , ICsvSerializable
    {
        public AbstractItem (string name, double initialAmount, double warningTreshold)
        {
            this.name =name;
            this.amount = initialAmount;
            this.warningTreshold = warningTreshold;
        }



        private string name;
        private double amount;
        private double warningTreshold;

        public void SetAmount(double amount)
        {
            this.amount = amount;
        }

        public void SetName(string name)
        {
            this.name = name;
        }
        public void SetWarningTreshold(double treshold)
        {
            this.warningTreshold = treshold;
        }

        public string Name 
        {
            get { return name; }
            set { this.name = Name; }
        }
        public double Amount
        {
            get { return amount; }
            set { this.amount = Amount; }
        }
        public double WarningTreshold
        {
            get { return warningTreshold; }
            set { this.warningTreshold = WarningTreshold; }
        }

        /// <summary>
        /// aktualny stav (hmotnost, objem) polozky v sklade
        /// </summary>
        public string GetName() {
            return name;
        }
        public double GetAmount() {
            return amount;
        }

        /// <summary>
        /// kriticky stav (hmotnost,objem) polozky v sklade
        /// </summary>
        public double GetWarningTreshold()
        {  
            return warningTreshold;  
        }


        /// <summary>
        /// testuje ci mnozstvo polozky (hmotnost,objem) nieje kriticke
        /// </summary>
        /// <param name="mnozstvo"></param>
        /// <returns>true - mozstvo je kriticke;false - mnozstvo nieje kriticke</returns>
        public bool IsLow()
        {
            /*if (mnozstvo <= warningTreshold)
            {
                return true;
            }
            return false;*/
            return amount <= warningTreshold ? true : false;
        }

        /// <summary>
        /// zvysuje mnozstvo(objem,hmotnost) polozky 
        /// </summary>
        /// <param name="mnozstvo"></param>
        /// <returns>vrati aktualizovany stav polozky</returns>
        public void Add(double mnozstvo)
        {
            this.amount += mnozstvo;

        }
        /// <summary>
        /// znizuje mnozstvo(objem,hmotnost) polozky
        /// </summary>
        /// <param name="mnozstvo"></param>
        /// <returns>vrati aktualny stav polozky</returns>
        ///  Odpaluje <exception cref="InsufficientIngredientsException"</exception>
        public void Remove(double mnozstvo)
        {
            try
            {
                if (amount - mnozstvo <= 0)
                {
                    //HandleError();
                    throw new InsufficientIngredientsException( $"Malo polozky na sklade: {nameof(Name)}, aktualny stav:{amount} ziadane mnozstvo:{mnozstvo}");
                }
                this.amount -= mnozstvo;
            }
            catch (InsufficientIngredientsException ex)
            {
                string msg = ex.Message;
                //PrintError("Malo surovin");
            }
        }

        /// <summary>
        /// metoda zapisuje do csv suboru
        /// </summary>
        /// <param name="polozka">typu Ingredient, alebo MiscellaneousItem </param>
        /// <param name="meno"></param>
        /// <param name="mnozstvo"></param>
        /// <returns></returns>

        virtual public string ToCsvLine()
        {
            return string.Format("{0},{1},{2},{3}","Ingredient" , Name, Convert.ToString(amount, CultureInfo.InvariantCulture) , Convert.ToString(warningTreshold, CultureInfo.InvariantCulture));
        }

    }
}
