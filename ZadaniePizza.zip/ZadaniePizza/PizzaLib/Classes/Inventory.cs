﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaLib.Classes
{
    public class Inventory : IInventory
    {
        List<AbstractItem> items;//polozky na sklade
        List<ICsvSerializable> CSVToFileLines;
        public Inventory(List<AbstractItem> zoznamPoloziek, List<ICsvSerializable> CSVprvky)
        {
            this.CSVToFileLines = CSVprvky;
            this.items = zoznamPoloziek;
        }

        public List<AbstractItem>  GetItems() 
        {
            return items;
        }
        /// <summary>
        /// prida polozku do zoznamu ak nieje v zozname
        /// </summary>
        /// <param name="polozka"></param>
        /// <returns>vrati pocet poloziek v zozname</returns>
        public List<AbstractItem> GetItemsByPredicate(Func<AbstractItem, bool> predicate)
        {
            return items.Where(predicate).ToList(); ;
        }

        /// <summary>
        /// funkcia pre pridavanie poloziek do inventara
        /// </summary>
        /// <param name="item"></param>
        public void AddItem(AbstractItem item)
        {
            if (!ItemExists(item))
            { 
                items.Add(item);
            CSVToFileLines.Add((ICsvSerializable)item);
            }
            else
                throw new ArgumentException($"Polozka {nameof(item)} na sklade uz existuje");           
        }

        /// <summary>
        /// testuje ci existuje polozka v zozname
        /// </summary>
        /// <param name="item"></param>
        /// <returns>true polozka existuje; false polozka neexistuje;</returns>

        bool ItemExists(AbstractItem  item) 
        {
            bool result = items.Any(p => p.Name == item.Name);
            return result;
        }

        //TODO : bolo by vhodne pridat metodu na ulozenie zoznamPoloziek do Csv suboru sklad.csv 
        // A nacitat polozky zo suboru do zoznamPoloziek

        /// <summary>
        /// podla nazvu vrati polozku zo skladu
        /// </summary>
        /// <param name="nazovPolozky"></param>
        /// <returns>null - pozozka s nazovPolozky na sklade neexistuje; vrati polozku typu Item podla nazov polozky</returns>
        public AbstractItem GetItem(Predicate<AbstractItem> predicate)
        {
            return items.First(item => predicate(item));
        }

    }
}
