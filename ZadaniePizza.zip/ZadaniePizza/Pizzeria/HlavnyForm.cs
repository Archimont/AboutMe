﻿using PizzaLib.Classes;
using Sklad;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizzeria
{
    public partial class Stolymenu : Form
    {
        private Fasada material = new Fasada();

        public Stolymenu()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonSklad_Click(object sender, EventArgs e)
        {
            using (Form1 sklad = new Form1(material.getInventory(),material.GetRestaurantMenu() ) )
            {
                sklad.ShowDialog();
            }
        }

        private void buttonStoly_Click(object sender, EventArgs e)
        {
            using (Form4 stoly = new Form4(material.GetRestaurantMenu(),material.getInventory()))
            {
                stoly.ShowDialog();
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            material.SaveActualPizzeria();
            this.Close();
        }
    }
}
