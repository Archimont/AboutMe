﻿namespace Pizzeria
{
    partial class Stolymenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonSklad = new System.Windows.Forms.Button();
            this.buttonStoly = new System.Windows.Forms.Button();
            this.buttonSave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonSklad
            // 
            this.buttonSklad.Location = new System.Drawing.Point(50, 35);
            this.buttonSklad.Name = "buttonSklad";
            this.buttonSklad.Size = new System.Drawing.Size(212, 100);
            this.buttonSklad.TabIndex = 0;
            this.buttonSklad.Text = "Sklad";
            this.buttonSklad.UseVisualStyleBackColor = true;
            this.buttonSklad.Click += new System.EventHandler(this.buttonSklad_Click);
            // 
            // buttonStoly
            // 
            this.buttonStoly.Location = new System.Drawing.Point(50, 163);
            this.buttonStoly.Name = "buttonStoly";
            this.buttonStoly.Size = new System.Drawing.Size(212, 100);
            this.buttonStoly.TabIndex = 1;
            this.buttonStoly.Text = "Stoly";
            this.buttonStoly.UseVisualStyleBackColor = true;
            this.buttonStoly.Click += new System.EventHandler(this.buttonStoly_Click);
            // 
            // buttonSave
            // 
            this.buttonSave.Location = new System.Drawing.Point(50, 300);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(212, 100);
            this.buttonSave.TabIndex = 2;
            this.buttonSave.Text = "Ulozit";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // Stolymenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.buttonStoly);
            this.Controls.Add(this.buttonSklad);
            this.Name = "Stolymenu";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonSklad;
        private System.Windows.Forms.Button buttonStoly;
        private System.Windows.Forms.Button buttonSave;
    }
}

