﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZadanieOOP.Classes;

namespace ZadanieOOP
{
    public partial class Editor : Form
    {
        private TrainStation station;
        private Train train;
        private bool edit = false;
        public Editor()
        {
            InitializeComponent();
        }

        public Editor(TrainStation station) : this()
        {
            this.station = station;
        }
        public Editor(Train train) : this()
        {
            this.train = train;
            textBoxName.Text = train.TrainNumber ;
            textBoxbegin.Text = train.Origin;
            textBoxstart.Text = train.ArrivalTime;
            textBoxfind.Text = train.Destination;
            textBoxend.Text = train.DepartureTime;
            edit = true;
        }


        private void Editor_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (edit)
            {
                train.TrainNumber = textBoxName.Text;
                train.SetArrival(textBoxstart.Text);
                train.SetDeparture(textBoxend.Text);
            }
            else 
            {
                Train train = new Train(textBoxName.Text, textBoxbegin.Text, DeserializeTime(textBoxstart.Text), textBoxfind.Text, DeserializeTime(textBoxend.Text));
                station.AddTrain(train);
            }
            this.Close();
        }

        private Time DeserializeTime(string line)
        {
            string[] data = line.Split(':');
            return new Time(Convert.ToInt32(data[0]), Convert.ToInt32(data[1]));
        }

        private void buttonStorno_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
