﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZadanieOOP.Classes
{
    public class Time
    {
        private int hour;
        public int Hour
        {
            get { return hour; }
            set { this.hour = Hour; }
        }

        private int minute;
        public int Minute
        {
            get { return minute; }
            set { this.minute = Minute; }
        }

        public Time(int Hour , int Minute ) 
        {
            this.hour = Hour;
            this.minute = Minute;
        }

        public string GetTime() 
        {
            if (this.minute > 9)
            {
                return this.hour.ToString() + ":" + this.minute.ToString();
            }
            else return this.hour.ToString() + ":0" + this.minute.ToString();
        }
        public void SetTime(string time) 
        {
            string[] data = time.Split(':');
            this.hour = Convert.ToInt32(data[0]);
            this.minute = Convert.ToInt32(data[1]);
        }
        
        public bool SmallerThan(Time time) 
        {
            if (time.Hour > this.hour){ return true; }
            if (time.Minute > this.minute) { return true; }
            else return false;
        }

        public bool Equals(Time time) 
        {
            if (time.Hour == this.hour && time.Minute == this.minute){ return true; }
            else return false;
        }

        public bool GreatherThan(Time time) 
        {
            if (time.Hour < this.hour) { return true; }
            if (time.Minute < this.minute) { return true; }
            else return false;
        }

        public void Add(Time time) 
        {
            this.hour += time.Hour;
            if (this.minute + time.Minute > 59) 
            {
                this.minute += time.Minute - 60;
                this.hour += 1;
            }
        }

        public Time Clone() 
        {
            return new Time(Hour,Minute);
        }

        public void tick() 
        {
            this.minute += 1;
            if (this.minute > 59)
            {
                this.minute -=  60;
                this.hour += 1;
            }
        }
    }
}
