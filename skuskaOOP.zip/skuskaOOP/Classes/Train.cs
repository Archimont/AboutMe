﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZadanieOOP.Classes
{
    public class Train
    {
        private string trainNumber;
        private string origin;
        private Time arrivalTime;
        private string destination;
        private Time departureTime;
        private Time delay;
        private string status;

        public Train(string TrainNumber , string Origin , Time ArrivalTime , string Destination , Time DepartureTime) 
        {
            this.trainNumber = TrainNumber;
            this.origin = Origin;
            this.arrivalTime = ArrivalTime;
            this.destination = Destination;
            this.departureTime = DepartureTime;
        }

        public string TrainNumber
        {
            get { return trainNumber; }
            set { this.trainNumber = TrainNumber; }
        }
        public string Origin
        {
            get { return origin; }
            set { this.origin = Origin; }
        }
        public string ArrivalTime
        {
            get { return arrivalTime.GetTime(); }
        }
        public string Destination
        {
            get { return destination; }
            set { this.destination = Destination; }
        }
        public string DepartureTime
        {
            get { return departureTime.GetTime(); }
        }

        public void SetArrival(string time ) 
        {
            this.arrivalTime.SetTime(time);
        }

        public void SetDeparture(string time) 
        {
            this.departureTime.SetTime(time);        
        }

    }
}
