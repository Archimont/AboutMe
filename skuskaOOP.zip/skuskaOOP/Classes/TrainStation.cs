﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZadanieOOP.Classes
{
    public class TrainStation
    {
        private List<Train> trains;

        public TrainStation(List<Train> trains) 
        {
            this.trains = trains;
        }

        public List<Train> GetITrainsByPredicate(Func<Train, bool> predicate)
        {
            return trains.Where(predicate).ToList(); 
        }

        public void AddTrain(Train train) 
        {
            trains.Add(train);
        }

        public List<Train> GetTrains()
        {
            return trains;
        }
    }
}
