﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZadanieOOP.Classes
{
    public class CsvReader
    {
        private readonly string path;
        public CsvReader(string path)
        {
            this.path = path;
        }


        public List<Train> LoadFromFile()
        {
            List<Train> lines = new List<Train>();
            using (StreamReader sr = new StreamReader(path))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    lines.Add(Deserialize(line));
                }
            }

            return lines;
        }

        private Train Deserialize(string line)
        {
            string[] data = line.Split(';');
            return new Train(data[0], data[1],DeserializeTime(data[2]),data[3],DeserializeTime(data[4]));
        }

        private Time DeserializeTime(string line)
        {
            string[] data = line.Split(':');
            return new Time(Convert.ToInt32(data[0]), Convert.ToInt32(data[1]));
        }
    }
}
