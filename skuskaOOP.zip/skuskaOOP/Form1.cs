﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZadanieOOP.Classes;

namespace ZadanieOOP
{
    public partial class Form1 : Form
    {
        private CsvReader Reader = new CsvReader("Trains.txt");
        private TrainStation station;
        private BindingSource bindingSource = new BindingSource();
        private Time actualTime = new Time(10, 28);
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            station = new TrainStation(Reader.LoadFromFile());
            bindingSource.DataSource = station.GetTrains();
            dataGridViewTrains.DataSource = bindingSource;
            bindingSource.ResetBindings(false);
        }

        private void textBoxStart_TextChanged(object sender, EventArgs e)
        {
            Func<Train, bool> predicate = train => train.Origin.ToLower().Contains(textBoxStart.Text);
            bindingSource.DataSource = station.GetITrainsByPredicate(predicate);
            dataGridViewTrains.DataSource = bindingSource;
            bindingSource.ResetBindings(false);
        }

        private void textBoxEnd_TextChanged(object sender, EventArgs e)
        {
            Func<Train, bool> predicate = train => train.Destination.ToLower().Contains(textBoxEnd.Text);
            bindingSource.DataSource = station.GetITrainsByPredicate(predicate);
            dataGridViewTrains.DataSource = bindingSource;
            bindingSource.ResetBindings(false);
        }

        private void buttonNew_Click(object sender, EventArgs e)
        {
            using (Editor form = new Editor(this.station))
            {
                form.ShowDialog();
            }
            bindingSource.DataSource = station.GetTrains();
            bindingSource.ResetBindings(false);
        }

        private void dataGridViewTrains_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Train train = (Train)dataGridViewTrains.CurrentRow.DataBoundItem;
            using (Editor form = new Editor(train))
            {
                form.ShowDialog();
            }
            bindingSource.DataSource = station.GetTrains();
            bindingSource.ResetBindings(false);
        }
    }
}
